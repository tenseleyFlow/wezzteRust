<script>
  import { onMount } from 'svelte';
  import { invoke } from '@tauri-apps/api/core';
  import WidgetPanel from '../lib/components/WidgetPanel.svelte';
  import ConfigPreview from '../lib/components/ConfigPreview.svelte';
  
  let widgets = {};
  let configPreview = '';
  let loading = false;
  let error = '';
  
  async function loadSampleConfig() {
    try {
      loading = true;
      error = '';
      
      // Get sample config from Tauri backend
      const sampleConfig = await invoke('get_sample_config');
      
      // Parse the configuration and create widgets
      const result = await invoke('parse_config', { 
        configContent: sampleConfig 
      });
      
      widgets = result.widgets;
      configPreview = result.config_preview;
    } catch (err) {
      error = `Error loading config: ${err}`;
      console.error('Config loading error:', err);
    } finally {
      loading = false;
    }
  }
  
  async function handleWidgetUpdate(event) {
    try {
      const { widgetId, value } = event.detail;
      
      // Update widget via Tauri command and get updated state
      const result = await invoke('update_widget', {
        widgetId,
        value
      });
      
      // Update local state with the response
      widgets = result.widgets;
      configPreview = result.config_preview;
    } catch (err) {
      error = `Error updating widget: ${err}`;
      console.error('Widget update error:', err);
    }
  }
  
  onMount(() => {
    loadSampleConfig();
  });
</script>

<div class="app-container">
  <header class="app-header">
    <h1>🎨 Wezztershier - WezTerm Configuration</h1>
    <p>Beautiful GUI for configuring WezTerm settings</p>
  </header>
  
  {#if error}
    <div class="error-banner">
      {error}
      <button on:click={() => error = ''}>✕</button>
    </div>
  {/if}
  
  {#if loading}
    <div class="loading">
      <div class="spinner"></div>
      <p>Loading configuration...</p>
    </div>
  {:else}
    <div class="content">
      <div class="widgets-section">
        <WidgetPanel 
          {widgets} 
          on:widgetUpdate={handleWidgetUpdate}
        />
      </div>
      
      <div class="preview-section">
        <ConfigPreview {configPreview} />
      </div>
    </div>
  {/if}
</div>

<style>
  .app-container {
    height: 100vh;
    display: flex;
    flex-direction: column;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  }
  
  .app-header {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    padding: 1rem 2rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  }
  
  .app-header h1 {
    margin: 0;
    color: white;
    font-size: 1.5rem;
    font-weight: 600;
  }
  
  .app-header p {
    margin: 0.25rem 0 0 0;
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.9rem;
  }
  
  .error-banner {
    background: #ff4444;
    color: white;
    padding: 1rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .error-banner button {
    background: none;
    border: none;
    color: white;
    font-size: 1.2rem;
    cursor: pointer;
    padding: 0.25rem 0.5rem;
  }
  
  .loading {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: white;
  }
  
  .spinner {
    width: 40px;
    height: 40px;
    border: 4px solid rgba(255, 255, 255, 0.3);
    border-left-color: white;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 1rem;
  }
  
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  
  .content {
    flex: 1;
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1px;
    background: rgba(255, 255, 255, 0.1);
  }
  
  .widgets-section,
  .preview-section {
    background: rgba(255, 255, 255, 0.95);
    overflow-y: auto;
  }
</style>