use wezztershier_core::{
    parser::{parse_decorator_line, parse_annotations},
    widgets::{
        implementations::register_core_widgets,
        factory::{WidgetFactory, WidgetBuilder},
    },
};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    // Initialize tracing
    tracing_subscriber::fmt::init();
    
    println!("🎉 WezzteRust Phase 2 - Widget Factory Complete!");
    
    // Register core widgets
    register_core_widgets()?;
    println!("📦 Registered {} core widgets", WidgetFactory::registered_types()?.len());
    
    // Test parsing and widget creation
    let sample_config = r##"
-- <<TUNER-START>>
-- @ui: slider(min=10, max=42, step=1) type=int
config.font_size = 18
-- @ui: select(options="Dark, Light, Auto") type=string
config.color_scheme = "Dark"
-- @ui: color_picker(format="hex", alpha=false) type=color
config.colors.background = "#333333"
-- <<TUNER-END>>
"##;

    println!("🔍 Parsing sample configuration...");
    let entries = parse_annotations(sample_config)?;
    println!("📊 Found {} configuration entries", entries.len());

    // Create widgets
    println!("🏗️  Creating widgets...");
    let mut builder = WidgetBuilder::new();
    let widget_ids = builder.add_from_entries(&entries)?;
    
    println!("✨ Created {} widgets:", widget_ids.len());
    for widget_id in &widget_ids {
        let widget = builder.get_widget(widget_id).unwrap();
        println!("   • {} ({}): {}", 
            widget.config().label,
            widget_id, 
            widget.to_config_string()
        );
    }

    // Test widget updates
    println!("\n🔧 Testing widget updates...");
    use wezztershier_core::widgets::traits::WidgetValue;
    
    // Update slider value
    if let Some(slider_id) = widget_ids.first() {
        builder.update_widget_value(slider_id, WidgetValue::Number(24.0))?;
        let widget = builder.get_widget(slider_id).unwrap();
        println!("   📏 Updated slider: {} = {}", widget.config().label, widget.to_config_string());
    }

    // Generate configuration
    println!("\n📝 Generated configuration:");
    println!("{}", builder.generate_config());

    // Show debug info
    println!("\n🐛 Registry Debug Info:");
    println!("{}", WidgetFactory::debug_info()?);

    println!("\n✅ Phase 2 Complete - Widget system is working!");
    println!("🚀 Ready for Phase 3: GUI Framework (Tauri + Svelte)");
    
    Ok(())
}
