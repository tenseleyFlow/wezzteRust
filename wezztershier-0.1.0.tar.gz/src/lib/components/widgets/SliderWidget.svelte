<script>
  import { createEventDispatcher } from 'svelte';
  
  export let widget;
  export let widgetId;
  
  const dispatch = createEventDispatcher();
  
  $: sliderData = widget.slider;
  $: currentValue = widget.current_value;
  
  let inputValue = currentValue;
  
  // Sync input value when widget data changes
  $: inputValue = currentValue;
  
  function handleInput(event) {
    const value = parseFloat(event.target.value);
    inputValue = value;
    dispatch('change', value);
  }
  
  function formatValue(value) {
    if (sliderData.step && sliderData.step < 1) {
      return parseFloat(value).toFixed(1);
    }
    return Math.round(value).toString();
  }
</script>

<div class="slider-widget">
  <div class="slider-container">
    <input
      type="range"
      min={sliderData.min}
      max={sliderData.max}
      step={sliderData.step || 1}
      value={inputValue}
      on:input={handleInput}
      class="slider"
    />
  </div>
  
  <div class="slider-info">
    <div class="value-display">
      <span class="current-value">{formatValue(inputValue)}</span>
      <span class="unit">{sliderData.unit || ''}</span>
    </div>
    
    <div class="range-display">
      <span class="range-min">{sliderData.min}</span>
      <span class="range-separator">—</span>
      <span class="range-max">{sliderData.max}</span>
    </div>
  </div>
  
  {#if sliderData.step}
    <div class="step-info">
      Step: {sliderData.step}
    </div>
  {/if}
</div>

<style>
  .slider-widget {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }
  
  .slider-container {
    position: relative;
  }
  
  .slider {
    width: 100%;
    height: 6px;
    border-radius: 3px;
    background: #e0e0e0;
    outline: none;
    transition: background 0.2s ease;
    cursor: pointer;
  }
  
  .slider::-webkit-slider-thumb {
    appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #667eea;
    cursor: pointer;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    transition: all 0.2s ease;
  }
  
  .slider::-webkit-slider-thumb:hover {
    background: #5a67d8;
    transform: scale(1.1);
  }
  
  .slider::-moz-range-thumb {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #667eea;
    cursor: pointer;
    border: none;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  }
  
  .slider::-moz-range-track {
    height: 6px;
    border-radius: 3px;
    background: #e0e0e0;
    border: none;
  }
  
  .slider-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.9rem;
  }
  
  .value-display {
    display: flex;
    align-items: center;
    gap: 0.25rem;
  }
  
  .current-value {
    font-weight: 600;
    color: #667eea;
    font-size: 1rem;
  }
  
  .unit {
    color: #666;
    font-size: 0.8rem;
  }
  
  .range-display {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #666;
    font-size: 0.8rem;
  }
  
  .range-separator {
    opacity: 0.5;
  }
  
  .step-info {
    font-size: 0.75rem;
    color: #888;
    text-align: center;
  }
</style>