<script>
  import { createEventDispatcher } from 'svelte';
  
  export let widget;
  export let widgetId;
  
  const dispatch = createEventDispatcher();
  
  $: selectData = widget.select;
  $: currentValue = widget.current_value;
  
  let selectedValue = currentValue;
  
  // Sync selected value when widget data changes
  $: selectedValue = currentValue;
  
  function handleChange(event) {
    const value = event.target.value;
    selectedValue = value;
    dispatch('change', value);
  }
</script>

<div class="select-widget">
  <div class="select-container">
    <select
      value={selectedValue}
      on:change={handleChange}
      class="select-input"
    >
      {#each selectData.options as option}
        <option value={option.value}>
          {option.label}
        </option>
      {/each}
    </select>
    
    <div class="select-arrow">
      <svg width="12" height="8" viewBox="0 0 12 8" fill="none">
        <path d="M1 1L6 6L11 1" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    </div>
  </div>
  
  <div class="select-info">
    <span class="option-count">{selectData.options.length} options available</span>
  </div>
</div>

<style>
  .select-widget {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .select-container {
    position: relative;
  }
  
  .select-input {
    width: 100%;
    padding: 0.75rem 2.5rem 0.75rem 1rem;
    border: 2px solid #e0e0e0;
    border-radius: 6px;
    font-size: 0.95rem;
    background: white;
    color: #333;
    cursor: pointer;
    transition: all 0.2s ease;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
  }
  
  .select-input:hover {
    border-color: #c0c0c0;
  }
  
  .select-input:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  .select-arrow {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    color: #666;
    pointer-events: none;
    transition: color 0.2s ease;
  }
  
  .select-input:focus + .select-arrow {
    color: #667eea;
  }
  
  .select-info {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }
  
  .option-count {
    font-size: 0.75rem;
    color: #888;
  }
</style>