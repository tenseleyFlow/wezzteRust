<script>
  import { createEventDispatcher } from 'svelte';
  
  export let widget;
  export let widgetId;
  
  const dispatch = createEventDispatcher();
  
  $: colorData = widget.color_picker;
  $: currentValue = widget.current_value;
  
  let colorValue = currentValue;
  
  // Sync color value when widget data changes
  $: colorValue = currentValue;
  
  function handleColorChange(event) {
    const value = event.target.value;
    colorValue = value;
    dispatch('change', value);
  }
  
  function handleTextChange(event) {
    const value = event.target.value;
    colorValue = value;
    dispatch('change', value);
  }
  
  // Convert hex to display format
  function formatColorForDisplay(color) {
    if (colorData.format === 'hex') {
      return color.startsWith('#') ? color : `#${color}`;
    }
    return color;
  }
  
  // Get color for the color input (always needs to be hex)
  function getColorInputValue(color) {
    if (color.startsWith('#')) {
      return color.slice(0, 7); // Remove alpha channel for color input
    }
    return color;
  }
</script>

<div class="color-picker-widget">
  <div class="color-input-group">
    <div class="color-visual">
      <input
        type="color"
        value={getColorInputValue(colorValue)}
        on:input={handleColorChange}
        class="color-input"
        title="Pick a color"
      />
      <div 
        class="color-preview" 
        style="background-color: {formatColorForDisplay(colorValue)}"
      ></div>
    </div>
    
    <div class="text-input-container">
      <input
        type="text"
        value={colorValue}
        on:input={handleTextChange}
        placeholder="Enter color value"
        class="text-input"
      />
    </div>
  </div>
  
  <div class="color-info">
    <div class="format-info">
      <span class="format-label">Format:</span>
      <span class="format-value">{colorData.format.toUpperCase()}</span>
    </div>
    
    {#if colorData.alpha_enabled}
      <div class="alpha-info">
        <span class="alpha-label">✓ Alpha enabled</span>
      </div>
    {/if}
    
    {#if colorData.parsed_color}
      <div class="rgb-info">
        RGB: {colorData.parsed_color.r}, {colorData.parsed_color.g}, {colorData.parsed_color.b}
        {#if colorData.parsed_color.a !== 1.0}
          (α: {(colorData.parsed_color.a * 100).toFixed(0)}%)
        {/if}
      </div>
    {/if}
  </div>
</div>

<style>
  .color-picker-widget {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }
  
  .color-input-group {
    display: flex;
    gap: 0.75rem;
    align-items: center;
  }
  
  .color-visual {
    position: relative;
    flex-shrink: 0;
  }
  
  .color-input {
    width: 48px;
    height: 48px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    padding: 0;
    background: none;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease;
  }
  
  .color-input:hover {
    transform: scale(1.05);
  }
  
  .color-input::-webkit-color-swatch {
    border: none;
    border-radius: 8px;
  }
  
  .color-input::-moz-color-swatch {
    border: none;
    border-radius: 8px;
  }
  
  .color-preview {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border-radius: 8px;
    pointer-events: none;
    border: 2px solid rgba(255, 255, 255, 0.8);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  
  .text-input-container {
    flex: 1;
  }
  
  .text-input {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 2px solid #e0e0e0;
    border-radius: 6px;
    font-size: 0.9rem;
    font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
    background: white;
    color: #333;
    transition: all 0.2s ease;
  }
  
  .text-input:hover {
    border-color: #c0c0c0;
  }
  
  .text-input:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  .color-info {
    display: flex;
    flex-direction: column;
    gap: 0.375rem;
    font-size: 0.8rem;
    color: #666;
  }
  
  .format-info,
  .alpha-info,
  .rgb-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .format-label,
  .alpha-label {
    font-weight: 500;
  }
  
  .format-value {
    font-family: monospace;
    background: #f0f0f0;
    padding: 0.125rem 0.375rem;
    border-radius: 3px;
  }
  
  .alpha-info {
    color: #22c55e;
  }
  
  .rgb-info {
    font-family: monospace;
    font-size: 0.75rem;
    color: #888;
    justify-content: center;
  }
</style>